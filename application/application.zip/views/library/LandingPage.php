    <div class="page-container container">
        <div class="row">
            <div class="col-md-12 entry-content">
                <article>


                    <div class="row wpb_row row-fluid custom_1491403460554 row-o-equal-height row-flex">
                        <div class="wpb_column column_container col-sm-3">
                            <div class="column-inner custom_1487239752272">
                                <div class="wpb_wrapper"></div>
                            </div>
                        </div>


                        <div class="wpb_column column_container col-sm-6">

                            <div class="column-inner">
                                <div class="wpb_wrapper">
                                    <!-- <div class="mgt-header-block clearfix text-center text-black wpb_content_element mgt-header-block-style-2 mgt-header-block-fontsize-medium mgt-header-texttransform-none mgt-header-block-64598258 custom_1491832385647">
                                        <a class="search-toggle-btn">Cari <i class="fa fa-search"></i></a>
                                        <input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false">
                                        <div class="mgt-header-line mgt-header-line-margin-small"></div>
                                    </div> -->

                                    <div class="mgt-header-block clearfix text-center text-black wpb_content_element mgt-header-block-style-2 mgt-header-block-fontsize-medium mgt-header-texttransform-none mgt-header-block-64598258 custom_1491832385647">
                                        <!-- <p class="mgt-header-block-subtitle">sliders</p> -->
                                        <h2 class="mgt-header-block-title text-font-weight-default">Digital Library</h2>
                                        <div class="mgt-header-line mgt-header-line-margin-small"></div>
                                    </div>
                                    <div class="wpb_text_column wpb_content_element text-size-medium">
                                        <div class="wpb_wrapper">
                                            <p style="text-align: center;">Baca buku, berbagi koleksi bacaan dan bersosialisasi secara bersamaan. Di mana pun, kapan pun dengan nyaman bersama Fakultas Ilmu Kesehatan Masyarakat Universitas Sriwijaya.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column column_container col-sm-3">
                            <div class="column-inner">
                                <div class="wpb_wrapper"></div>
                            </div>
                        </div>
                    </div>
                    <div data-vc-full-width="true" data-vc-full-width-init="true" class="row wpb_row row-fluid custom_1492102759246 row-has-fill" style="position: relative; left: -74.5px; box-sizing: border-box; width: 1349px; padding-left: 74.5px; padding-right: 74.5px;">
                        <div class="wpb_column column_container col-sm-6">
                            <div class="column-inner">
                                <div class="wpb_wrapper">
                                    <div class="mgt-flipbox mgt-flipbox-animation-horizontal mgt-flipbox-round-edges-disable mgt-flipbox-80375033 wpb_content_element">
                                        <div class="mgt-flipbox-front" data-style="background-image: url(<?= base_url('assets/img/img_1.jpg') ?>);" style="background-image: url(<?= base_url('assets/img/img_1.jpg') ?>);">
                                            <div class="mgt-flipbox-front-inner">
                                                <div class="mgt-flipbox-content-wrapper">
                                                    <div class="mgt-flipbox-icon"><i class="pe-7s-note2"></i></div>
                                                    <h4 class="mgt-flipbox-header">Jurnal</h4>
                                                    <div class="mgt-flipbox-description">Sedikit kemajuan setiap hari di dalam dirimu menambah sesuatu hingga hasil yang besar.</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mgt-flipbox-back" data-style="background-image: url(<?= base_url('assets/img/img_2.jpg') ?>);" style="background-image: url(<?= base_url('assets/img/img_2.jpg') ?>);">
                                            <div class="mgt-flipbox-back-inner">
                                                <div class="mgt-flipbox-content-wrapper">
                                                    <h4 class="mgt-flipbox-header">Jurnal</h4>
                                                    <div class="mgt-flipbox-description">Jangan mengharapkan semuanya bisa jadi lebih mudah, berharaplah agar dirimu bisa jadi lebih baik.</div>
                                                    <div class="mgt-flipbox-button">
                                                        <div class="mgt-button-wrapper mgt-button-wrapper-align-center mgt-button-wrapper-display-newline mgt-button-top-margin-false mgt-button-right-margin-false mgt-button-round-edges-small">
                                                            <a class="btn hvr-icon-wobble-horizontal mgt-button-icon-true mgt-button mgt-style-solid mgt-size-normal mgt-align-center mgt-display-newline mgt-text-size-small mgt-button-icon-separator- mgt-button-icon-position-right text-font-weight-default mgt-text-transform-none mgt-button-40678598" href="<?=base_url('journal')?>">
                                                                View more<i class="entypo-icon entypo-icon-right-open-mini"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column column_container col-sm-6">
                            <div class="column-inner">
                                <div class="wpb_wrapper">
                                    <div class="mgt-flipbox mgt-flipbox-animation-horizontal mgt-flipbox-round-edges-disable mgt-flipbox-31452337 wpb_content_element">
                                        <div class="mgt-flipbox-front" data-style="background-image: url(<?= base_url('assets/img/img_3.jpg') ?>);" style="background-image: url(<?= base_url('assets/img/img_3.jpg') ?>);">
                                            <div class="mgt-flipbox-front-inner">
                                                <div class="mgt-flipbox-content-wrapper">
                                                    <div class="mgt-flipbox-icon"><i class="pe-7s-portfolio"></i></div>
                                                    <h4 class="mgt-flipbox-header">Skripsi</h4>
                                                    <div class="mgt-flipbox-description">We only hire great people who strive to push their idea</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mgt-flipbox-back" data-style="background-image: url(<?= base_url('assets/img/img_4.jpg') ?>);" style="background-image: url(<?= base_url('assets/img/img_4.jpg') ?>);">
                                            <div class="mgt-flipbox-back-inner">
                                                <div class="mgt-flipbox-content-wrapper">
                                                    <h4 class="mgt-flipbox-header">Skripsi</h4>
                                                    <div class="mgt-flipbox-description">Our goal is simple, to make things that people care about. We were founded on this principle and we will always be commited to it.</div>
                                                    <div class="mgt-flipbox-button">
                                                        <div class="mgt-button-wrapper mgt-button-wrapper-align-center mgt-button-wrapper-display-newline mgt-button-top-margin-false mgt-button-right-margin-false mgt-button-round-edges-small">
                                                            <a class="btn hvr-icon-wobble-horizontal mgt-button-icon-true mgt-button mgt-style-solid mgt-size-normal mgt-align-center mgt-display-newline mgt-text-size-small mgt-button-icon-separator- mgt-button-icon-position-right text-font-weight-default mgt-text-transform-none mgt-button-4664271" href="<?=base_url('skripsi')?>">
                                                                View more<i class="entypo-icon entypo-icon-right-open-mini"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="wpb_column column_container col-sm-4">
                            <div class="column-inner">
                                <div class="wpb_wrapper">
                                    <div class="mgt-flipbox mgt-flipbox-animation-horizontal mgt-flipbox-round-edges-disable mgt-flipbox-65037821 wpb_content_element">
                                        <div class="mgt-flipbox-front" data-style="background-image: url(<?= base_url('assets/img/slideshow_1.jpg') ?>);" style="background-image: url(<?= base_url('assets/img/slideshow_1.jpg') ?>);">
                                            <div class="mgt-flipbox-front-inner">
                                                <div class="mgt-flipbox-content-wrapper">
                                                    <div class="mgt-flipbox-icon"><i class="pe-7s-joy"></i></div>
                                                    <h4 class="mgt-flipbox-header">Extensive Documentation</h4>
                                                    <div class="mgt-flipbox-description">We createcreative content that bring culture and commerce together.</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mgt-flipbox-back" data-style="background-image: url(<?= base_url('assets/img/slideshow_1.jpg') ?>);" style="background-image: url(<?= base_url('assets/img/slideshow_1.jpg') ?>);">
                                            <div class="mgt-flipbox-back-inner">
                                                <div class="mgt-flipbox-content-wrapper">
                                                    <h4 class="mgt-flipbox-header">Extensive Documentation</h4>
                                                    <div class="mgt-flipbox-description">Our goal is simple, to make things that people care about. We were founded on this principle and we will always be commited to it.</div>
                                                    <div class="mgt-flipbox-button">
                                                        <div class="mgt-button-wrapper mgt-button-wrapper-align-center mgt-button-wrapper-display-newline mgt-button-top-margin-false mgt-button-right-margin-false mgt-button-round-edges-small">
                                                            <a class="btn hvr-icon-wobble-horizontal mgt-button-icon-true mgt-button mgt-style-solid mgt-size-normal mgt-align-center mgt-display-newline mgt-text-size-small mgt-button-icon-separator- mgt-button-icon-position-right text-font-weight-default mgt-text-transform-none mgt-button-10844991" href="#">
                                                                View more<i class="entypo-icon entypo-icon-right-open-mini"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="row-full-width clearfix"></div>
                    <!-- <div class="row wpb_row row-fluid custom_1487759468662">
                        <div class="wpb_column column_container col-sm-12">
                            <div class="column-inner">
                                <div class="wpb_wrapper">
                                    <div class="mgt-images-slider mgt-images-slider-centered mgt-images-slider-52483508 wpb_content_element">
                                        <div class="mgt-images-slider-items">
                                            <div class="mgt-images-slider-item">
                                                <a href="https://digilib.unsri.ac.id/" rel="lightbox"><img src="<?= base_url('assets/img/lib_unsri.jpg') ?>" alt="" /></a>
                                            </div>
                                            <div class="mgt-images-slider-item">
                                                <a href="https://digilib.unsri.ac.id/index.php/e-resource/online-database/45-e-books-springer" rel="lightbox"><img src="https://digilib.unsri.ac.id/media/k2/items/cache/37a06e4a72d6cb27621f1ed829bbee81_M.jpg" alt="" /></a>
                                            </div>
                                            <div class="mgt-images-slider-item">
                                                <a href="https://digilib.unsri.ac.id/index.php/e-resource/online-database/56-ebscohost" rel="lightbox">
                                                    <h1 class="text-center texttransform-none">sas</h1> <img src="https://digilib.unsri.ac.id/media/k2/items/cache/d3b3799d6611d677944f5f86a500beb3_XL.jpg" alt="" />
                                                </a>


                                            </div>


                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div> -->
                    <div data-vc-full-width="true" data-vc-full-width-init="false" class="row wpb_row row-fluid custom_1494250050053 row-has-fill">
                        <div class="wpb_column column_container col-sm-12">
                            <div class="column-inner">
                                <div class="wpb_wrapper">
                                    <div class="mgt-images-slider mgt-images-slider-padding mgt-images-slider-centered mgt-images-slider-38336350 wpb_content_element wpb_animate_when_almost_visible wpb_fadeInDown fadeInDown">
                                        <div class="mgt-images-slider-items">
                                            <div class="mgt-images-slider-item">
                                                <a href="https://digilib.unsri.ac.id/index.php/e-resource/online-database/14-proquest" rel="lightbox"><img src="https://digilib.unsri.ac.id/media/k2/items/cache/fd8b0f77d767f1f6640afba6916ff67c_M.jpg" alt="" /></a>
                                            </div>
                                            <div class="mgt-images-slider-item">
                                                <a href="https://digilib.unsri.ac.id/index.php/e-resource/online-database/45-e-books-springer" rel="lightbox"><img src="https://digilib.unsri.ac.id/media/k2/items/cache/37a06e4a72d6cb27621f1ed829bbee81_M.jpg" alt="" /></a>
                                            </div>
                                            <div class="mgt-images-slider-item">
                                                <a href="https://digilib.unsri.ac.id/index.php/e-resource/online-database/56-ebscohost" rel="lightbox"><img src="https://digilib.unsri.ac.id/media/k2/items/cache/d3b3799d6611d677944f5f86a500beb3_XL.jpg" alt="" /></a>
                                            </div>
                                            <div class="mgt-images-slider-item">
                                                <a href="https://digilib.unsri.ac.id/index.php/e-resource/online-database/57-wiley-online-library" rel="lightbox"><img src="https://digilib.unsri.ac.id/media/k2/items/cache/0548677e6432786dd8df61eb3aaec139_XL.jpg" alt="" /></a>
                                            </div>
                                            <div class="mgt-images-slider-item">
                                                <a href="https://digilib.unsri.ac.id/index.php/e-resource/online-database/58-ieee" rel="lightbox">
                                                    <img src="https://digilib.unsri.ac.id/media/k2/items/cache/954fb0ebf1d84fb921bfb0b6e045d57f_XL.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="mgt-images-slider-item">
                                                <a href="https://digilib.unsri.ac.id/index.php/e-resource/online-database/66-emerald-insight" rel="lightbox">
                                                    <img src="https://digilib.unsri.ac.id/media/k2/items/cache/4d8c9898b5bb88437f053c8b957f47f3_XL.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="mgt-images-slider-item">
                                                <a href="https://digilib.unsri.ac.id/index.php/e-resource/online-database/44-clinical-key" rel="lightbox">
                                                    <img src="https://digilib.unsri.ac.id/media/k2/items/cache/8fe3e0f34d3083cba6fe73d62a783d7f_XL.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="mgt-images-slider-item">
                                                <a href="https://digilib.unsri.ac.id/index.php/e-resource/online-database/67-science-direct" rel="lightbox">
                                                    <img src="https://digilib.unsri.ac.id/media/k2/items/cache/4695cb3b19cbf906e45dac0da0913068_XL.jpg" alt="" />
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                 <!--    <div class="row-full-width clearfix"></div>
                    <div class="row wpb_row row-fluid custom_1487759468662">
                        <div class="wpb_column column_container col-sm-6">
                            <div class="column-inner">
                                <div class="wpb_wrapper">
                                    <div class="mgt-images-slider mgt-images-slider-19511706 wpb_content_element">
                                        <div class="mgt-images-slider-items">
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/woman-laught.jpg" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/general-director-meet-up.jpg" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/Clients-days.jpg" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/fun-people-young.jpg" alt="" /></div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="wpb_column column_container col-sm-6">
                            <div class="column-inner">
                                <div class="wpb_wrapper">
                                    <div class="mgt-images-slider mgt-images-slider-61297117 wpb_content_element">
                                        <div class="mgt-images-slider-items">
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/woman-laught.jpg" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/general-director-meet-up.jpg" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/Clients-days.jpg" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/fun-people-young.jpg" alt="" /></div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row wpb_row row-fluid effect-hover-img-opacity effect-hover-img-color custom_1496241893239">
                        <div class="wpb_column column_container col-sm-12">
                            <div class="column-inner">
                                <div class="wpb_wrapper">
                                    <div class="mgt-images-slider mgt-images-slider-padding mgt-images-slider-65544032 wpb_content_element">
                                        <div class="mgt-images-slider-items">
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/Logo-B-1.png" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/logo-b-2.png" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/logo-b-3.png" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/logo-b-4.png" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/logo-b-5.png" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/logo-b-6.png" alt="" /></div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row wpb_row row-fluid effect-hover-img-grayscale custom_1496242106538">
                        <div class="wpb_column column_container col-sm-12">
                            <div class="column-inner">
                                <div class="wpb_wrapper">
                                    <div class="mgt-images-slider mgt-images-slider-padding mgt-images-slider-27550502 wpb_content_element">
                                        <div class="mgt-images-slider-items">
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/Logo-B-1.png" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/logo-b-2.png" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/logo-b-3.png" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/logo-b-4.png" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/logo-b-5.png" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/logo-b-6.png" alt="" /></div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="row wpb_row row-fluid custom_1496242066520 row-no-padding">
                        <div class="wpb_column column_container col-sm-12">
                            <div class="column-inner">
                                <div class="wpb_wrapper">
                                    <div class="mgt-images-slider mgt-images-slider-52180309 wpb_content_element">
                                        <div class="mgt-images-slider-items">
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/woman-withlaptop.jpg" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/fun-people-young.jpg" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/color-people.jpg" alt="" /></div>
                                            <div class="mgt-images-slider-item"><img src="<?= base_url('assets2/') ?>upload/workspace.jpg" alt="" /></div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row-full-width clearfix"></div>
                    <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="row wpb_row row-fluid row-no-padding">
                        <div class="wpb_column column_container col-sm-12">
                            <div class="column-inner">
                                <div class="wpb_wrapper">
                                    <div class="mgt-promo-block-container wpb_content_element">
                                        <div class="mgt-promo-block-wrapper">
                                            <div class="mgt-promo-block white-text cover-image darken mgt-promo-block-9588851" data-style="background-color: #f5f5f5;background-image: url(<?= base_url('assets/img/slideshow_1.jpg') ?>);background-repeat: no-repeat;height: 550px;">
                                                <div class="mgt-promo-block-content va-middle">
                                                    <div class="mgt-promo-block-content-inside custom_1493650027261">
                                                        <h5 style="text-align: center; margin-bottom: 0px;"><strong>Be with Barrel</strong></h5>
                                                        <h2 style="text-align: center;">
                                                            Focus on what<br />
                                                            matters to you
                                                        </h2>
                                                        <div class="mgt-button-wrapper mgt-button-wrapper-align-center mgt-button-wrapper-display-newline mgt-button-top-margin-true mgt-button-right-margin-false mgt-button-round-edges-small">
                                                            <a class="btn hvr-float mgt-button-icon-true mgt-button mgt-style-red mgt-size-large mgt-align-center mgt-display-newline mgt-text-size-normal mgt-button-icon-separator- mgt-button-icon-position-right text-font-weight-default mgt-text-transform-none" href="#">
                                                                Purchase template<i class="entypo-icon entypo-icon-right-open-mini"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> -->
                    <div class="row-full-width clearfix"></div>
                </article>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="<?= base_url('assets2/') ?>js/jquery.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/jquery-migrate.min.js"></script>

<script type="text/javascript">
    /* <![CDATA[ */
    var thickboxL10n = {
        next: "Next >",
        prev: "< Prev",
        image: "Image",
        of: "of",
        close: "Close",
        noiframes: "This feature requires inline frames. You have iframes disabled or your browser does not support them.",
        loadingAnimation: "http:\/\/wp.magnium-themes.com\/barrel\/barrel-1\/wp-includes\/js\/thickbox\/loadingAnimation.gif",
    };
    /* ]]> */
</script>
<script type="text/javascript">
    /* <![CDATA[ */
    var rlArgs = {
        script: "nivo",
        selector: "lightbox",
        customEvents: "",
        activeGalleries: "1",
        effect: "fade",
        clickOverlayToClose: "1",
        keyboardNav: "1",
        errorMessage: "The requested content cannot be loaded. Please try again later.",
    };
    /* ]]> */
</script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/responsive-lightbox/assets/nivo/nivo-lightbox.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/responsive-lightbox/js/frontd.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/js-skin.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/thickbox/thickbox.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/bootstrap.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/easing.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/select2/select2.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/owl-carousel/owl.carousel.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/jquery.nanoscroller.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/jquery.mixitup.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/TweenMax.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/template.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/js_front.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/waypoints.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/jquery.appear.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/jquery.countTo.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/skrollr.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/accordion.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/tta-autoplay.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/tabs.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/waypoints.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets2/') ?>js/plugins/slick.min.js"></script>


<script>
    (function($) {
        $(document).ready(function() {
            $(".mgt-images-slider.mgt-images-slider-52483508 .mgt-images-slider-items").on("init", function(slick) {
                $(".mgt-images-slider.mgt-images-slider-52483508 .mgt-images-slider-items").show();
            });

            $(".mgt-images-slider.mgt-images-slider-52483508 .mgt-images-slider-items").slick({
                pauseOnHover: false,
                infinite: true,
                autoplay: true,
                autoplaySpeed: 2000,
                slidesToShow: 3,
                slidesToScroll: 1,
                arrows: true,
                dots: true,
                speed: 300,
                centerMode: true,
                centerPadding: "",
                variableWidth: false,
                adaptiveHeight: false,
                fade: false,
                cssEase: "ease",
                vertical: false,
                responsive: [{
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            infinite: true,
                            dots: true,
                        },
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                ],
            });
        });
    })(jQuery);
</script>
<script>
    (function($) {
        $(document).ready(function() {
            $(".mgt-images-slider.mgt-images-slider-38336350 .mgt-images-slider-items").on("init", function(slick) {
                $(".mgt-images-slider.mgt-images-slider-38336350 .mgt-images-slider-items").show();
            });

            $(".mgt-images-slider.mgt-images-slider-38336350 .mgt-images-slider-items").slick({
                pauseOnHover: false,
                infinite: true,
                autoplay: true,
                autoplaySpeed: 2000,
                slidesToShow: 5,
                slidesToScroll: 1,
                arrows: true,
                dots: false,
                speed: 300,
                centerMode: true,
                centerPadding: "60px",
                variableWidth: false,
                adaptiveHeight: false,
                fade: false,
                cssEase: "ease",
                vertical: false,
                responsive: [{
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            infinite: true,
                            dots: true,
                        },
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                ],
            });
        });
    })(jQuery);
</script>
<script>
    (function($) {
        $(document).ready(function() {
            $(".mgt-images-slider.mgt-images-slider-19511706 .mgt-images-slider-items").on("init", function(slick) {
                $(".mgt-images-slider.mgt-images-slider-19511706 .mgt-images-slider-items").show();
            });

            $(".mgt-images-slider.mgt-images-slider-19511706 .mgt-images-slider-items").slick({
                pauseOnHover: false,
                infinite: true,
                autoplay: true,
                autoplaySpeed: 2000,
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: true,
                dots: true,
                speed: 300,
                centerMode: false,
                centerPadding: "60px",
                variableWidth: false,
                adaptiveHeight: false,
                fade: false,
                cssEase: "ease",
                vertical: false,
                responsive: [{
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            infinite: true,
                            dots: true,
                        },
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                ],
            });
        });
    })(jQuery);
</script>
<script>
    (function($) {
        $(document).ready(function() {
            $(".mgt-images-slider.mgt-images-slider-61297117 .mgt-images-slider-items").on("init", function(slick) {
                $(".mgt-images-slider.mgt-images-slider-61297117 .mgt-images-slider-items").show();
            });

            $(".mgt-images-slider.mgt-images-slider-61297117 .mgt-images-slider-items").slick({
                pauseOnHover: false,
                infinite: true,
                autoplay: true,
                autoplaySpeed: 2000,
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: true,
                dots: true,
                speed: 300,
                centerMode: false,
                centerPadding: "60px",
                variableWidth: false,
                adaptiveHeight: false,
                fade: true,
                cssEase: "linear",
                vertical: false,
                responsive: [{
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            infinite: true,
                            dots: true,
                        },
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                ],
            });
        });
    })(jQuery);
</script>
<script>
    (function($) {
        $(document).ready(function() {
            $(".mgt-images-slider.mgt-images-slider-65544032 .mgt-images-slider-items").on("init", function(slick) {
                $(".mgt-images-slider.mgt-images-slider-65544032 .mgt-images-slider-items").show();
            });

            $(".mgt-images-slider.mgt-images-slider-65544032 .mgt-images-slider-items").slick({
                pauseOnHover: false,
                infinite: true,
                autoplay: true,
                autoplaySpeed: 5000,
                slidesToShow: 5,
                slidesToScroll: 1,
                arrows: false,
                dots: false,
                speed: 300,
                centerMode: false,
                centerPadding: "60px",
                variableWidth: false,
                adaptiveHeight: true,
                fade: false,
                cssEase: "ease",
                vertical: false,
                responsive: [{
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            infinite: true,
                            dots: true,
                        },
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                ],
            });
        });
    })(jQuery);
</script>
<script>
    (function($) {
        $(document).ready(function() {
            $(".mgt-images-slider.mgt-images-slider-27550502 .mgt-images-slider-items").on("init", function(slick) {
                $(".mgt-images-slider.mgt-images-slider-27550502 .mgt-images-slider-items").show();
            });

            $(".mgt-images-slider.mgt-images-slider-27550502 .mgt-images-slider-items").slick({
                pauseOnHover: false,
                infinite: true,
                autoplay: true,
                autoplaySpeed: 2000,
                slidesToShow: 5,
                slidesToScroll: 1,
                arrows: false,
                dots: false,
                speed: 300,
                centerMode: false,
                centerPadding: "60px",
                variableWidth: false,
                adaptiveHeight: true,
                fade: false,
                cssEase: "ease",
                vertical: false,
                responsive: [{
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            infinite: true,
                            dots: true,
                        },
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                ],
            });
        });
    })(jQuery);
</script>
<script>
    (function($) {
        $(document).ready(function() {
            $(".mgt-images-slider.mgt-images-slider-52180309 .mgt-images-slider-items").on("init", function(slick) {
                $(".mgt-images-slider.mgt-images-slider-52180309 .mgt-images-slider-items").show();
            });

            $(".mgt-images-slider.mgt-images-slider-52180309 .mgt-images-slider-items").slick({
                pauseOnHover: false,
                infinite: true,
                autoplay: true,
                autoplaySpeed: 2000,
                slidesToShow: 2,
                slidesToScroll: 1,
                arrows: false,
                dots: false,
                speed: 300,
                centerMode: false,
                centerPadding: "60px",
                variableWidth: false,
                adaptiveHeight: false,
                fade: false,
                cssEase: "ease",
                vertical: false,
                responsive: [{
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            infinite: true,
                            dots: true,
                        },
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        },
                    },
                ],
            });
        });
    })(jQuery);
</script>


