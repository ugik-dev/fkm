<div class="container-fluid footer-wrapper">
	<div class="row">
		<div class="footer-sidebar-wrapper footer-sidebar-style-dark" data-style="">
			<div class="footer-sidebar sidebar container footer-sidebar-col-1">
				<ul id="footer-sidebar" class="clearfix">
					<li id="text-2" class="widget widget_text">
						<div class="textwidget">
							<p style="text-align: center; margin-bottom: 35px;"><img src="<?= base_url('assets/') ?>img/fkm_logo.png" alt="Logo" width="200" height="300" /></p>
							<!-- <p style="text-align: center;">
								Say hello <a href="#" class="__cf_email__">test@gmail.com</a>
							</p> -->
							<!-- <div style="display: table; margin: 0 auto;">
								<div class="widget_barrel_social_icons shortcode_barrel_social_icons">
									<div class="social-icons-wrapper">
										<ul>
											<li>
												<a href="index.html" target="_blank" class="a-facebook"><i class="fa fa-facebook"></i></a>
											</li>
											<li>
												<a href="index.html" target="_blank" class="a-twitter"><i class="fa fa-twitter"></i></a>
											</li>
											<li>
												<a href="index.html" target="_blank" class="a-behance"><i class="fa fa-behance"></i></a>
											</li>
											<li>
												<a href="index.html" target="_blank" class="a-dribbble"><i class="fa fa-dribbble"></i></a>
											</li>
											<li>
												<a href="index.html" target="_blank" class="a-pinterest"><i class="fa fa-pinterest"></i></a>
											</li>
										</ul>
									</div>
								</div>
							</div> -->
						</div>
					</li>
				</ul>
			</div>
		</div>
		<footer class="footer-style-dark footer-col-1">
			<div class="container">
				<div class="row">
					<div class="col-md-12 footer-menu">
						<div class="menu-footermenu-simple-container">
							<!-- <ul id="menu-footermenu-simple" class="footer-menu">
								<li class="menu-item"><a href="about-classic.html">Our services</a></li>
								<li class="menu-item"><a href="about-classic.html">Projects</a></li>
								<li class="menu-item"><a href="about-classic.html">Contact us</a></li>
								<li class="menu-item"><a href="about-classic.html">Disclaimer</a></li>
								<li class="menu-item"><a href="about-classic.html">Privacy policy</a></li>
							</ul> -->
						</div>
					</div>
					<!-- <div class="col-md-12 footer-copyright">Powered by <a href="https://themeforest.net/user/max-themes/" target="_blank" rel="noopener noreferrer">B-App - Landing App HTML Template</a></div> -->
				</div>
			</div>
			<a class="scroll-to-top" href="#top"></a>
		</footer>
	</div>
</div>
<!-- <nav id="offcanvas-sidebar-nav" class="st-sidebar-menu st-sidebar-effect-2">
	<div class="st-sidebar-menu-close-btn">
		<i class="pe-7s-close"></i>
	</div>
	<div class="offcanvas-sidebar sidebar">
		<ul id="offcanvas-sidebar" class="clearfix">
			<li id="nav_menu-7" class="widget widget_nav_menu">
				<h2 class="widgettitle">Navigation</h2>
				<div class="menu-offcanvas-container">
					<ul id="menu-offcanvas" class="menu">
						<li class="menu-item">
							<a href="index.html">Homepage</a>
						</li>
						<li class="menu-item"><a href="about-us.html">About us</a></li>
						<li class="menu-item"><a href="our-team.html">Our team</a></li>
						<li class="menu-item"><a href="blog.html">Blog</a></li>
						<li class="menu-item"><a href="portfolio-3.html">Portfolio</a></li>
						<li class="menu-item"><a href="contact-us-classic.html">Contact</a></li>
					</ul>
				</div>
			</li>
			<li id="text-9" class="widget widget_text">
				<h2 class="widgettitle">Our Brochures</h2>
				<div class="textwidget">
					<div class="widget-download-link-wrapper">
						<div class="widget-download-icon">
							<i class="fa fa-file-pdf-o"></i>
						</div>
						<div class="widget-download-details">
							<div class="widget-download-title">
								<a href="#">Company Brochure</a>
							</div>
							<div class="widget-download-subtitle">
								2.3 mb, PDF
							</div>
						</div>
					</div>
					<div class="widget-download-link-wrapper">
						<div class="widget-download-icon">
							<i class="fa fa-file-pdf-o"></i>
						</div>
						<div class="widget-download-details">
							<div class="widget-download-title">
								<a href="#">Price List</a>
							</div>
							<div class="widget-download-subtitle">
								2.3 mb, PDF
							</div>
						</div>
					</div>
				</div>
			</li>
		</ul>
	</div>
</nav> -->


<div class="search-fullscreen-container"></div>
<div class="search-fullscreen-wrapper">
	<div class="search-fullscreen-form">
		<div class="search-close-btn">
			<i class="pe-7s-close"></i>
		</div>
		<form method="get" id="searchform_p" class="searchform" action="<?= base_url() ?>library/search?">
			<input type="search" class="field" name="s" value="" id="s_p" placeholder="Type keyword(s) here and hit Enter &hellip;" />
			<input type="submit" class="submit btn" id="searchsubmit_p" value="Search" />
		</form>
	</div>
</div>
<div class="header-advanced-menu-fullscreen-container"></div>
<div class="header-advanced-menu-fullscreen-wrapper">

	<div class="header-advanced-menu-close-btn">
		<i class="pe-7s-close"></i>
	</div>


</div>
</body>

</html>