<div class="wrapper wrapper-content animated fadeInRight" id="periodeContainer">
  Dashboard
</div>

<script>
$(document).ready(function() {
  $('#dashboard').addClass('active');
});
</script>