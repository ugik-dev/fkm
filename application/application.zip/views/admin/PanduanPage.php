<div class="wrapper wrapper-content animated fadeInRight">
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-primary">
        <div class="panel-heading">
          Panduan
        </div>
        <div class="panel-body">
          <div>1. <a href="#" target="_blank">-</a></div>
        </div>
      </div>
    </div>
  </div>
</div>
 
<script>
$(document).ready(function() {
  $('#panduan').addClass('active');
});
</script>